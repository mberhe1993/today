package senay;

public interface IFormulaICell<E> extends IRef<E>, ICellObserver {
    IFormulaICell<E> addFormula(IOperation<E> IOperation, ICell<E> cell);
    void addCell(ICell<E> cell);
}
