package senay;

import java.util.List;

public interface IOperation<E> {
    void compute(List<ICell<E>> cells);
    E getValue();
}
