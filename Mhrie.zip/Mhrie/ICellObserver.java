package senay;

public interface ICellObserver {
    void update();
}
