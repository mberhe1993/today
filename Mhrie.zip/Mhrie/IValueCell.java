package senay;

public interface IValueCell<E> extends IRef<E> {
    void setValue(E value);
}
