package senay;

public interface IRef<E> extends ICell<E> {
}
