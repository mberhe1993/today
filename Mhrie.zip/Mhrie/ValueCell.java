package senay;

import java.util.ArrayList;
import java.util.List;

public class ValueCell implements IValueCell<Integer> {
    private int value;
    private List<ICellObserver> observers;

    public ValueCell(int value) {
        this.value = value;
        this.observers = new ArrayList<>();
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public void addObserver(ICellObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (ICellObserver observer : this.observers) {
            observer.update();
        }
    }

    @Override
    public void setValue(Integer value) {
        this.value = value;
        notifyObservers();
    }

    @Override
    public String toString() {
        return getValue().toString();
    }
}
