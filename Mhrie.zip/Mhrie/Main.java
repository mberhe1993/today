package senay;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("ANS #(1)");
        IValueCell<Integer> result1 = new ValueCell(5);
        IValueCell<Integer> result2 = new ValueCell(2);
        List<ICell<Integer>> compute = new ArrayList<>();
        compute.add(result1);
        compute.add(result2);
        IFormulaICell<Integer> result3 = new FormulaICell(compute, new OperationSum());

        System.out.println("result1: " + result1);
        System.out.println("result2: " + result2);
        System.out.println("result3 (result1 + result2): " + result3);

        System.out.println("\n");
        System.out.println("ANS #(2)");
        IFormulaICell<Integer> result4 = new FormulaICell(compute, new OperationSubtraction());
        System.out.println("result4 (result1 - result2): " + result4);
        List<ICell<Integer>>  compute2 = new ArrayList<>();
        compute2.add(result3);
        compute2.add(result4);
        IFormulaICell<Integer> result5 = new FormulaICell(compute2, new OperationMultiplication());
        System.out.println("result5 (result3 * result4): " + result5);

        List<ICell<Integer>>  compute3 = new ArrayList<>();
        compute3.add(result2);
        compute3.add(result3);
        IFormulaICell<Integer> result6 = new FormulaICell(compute3, new OperationMultiplication());
        System.out.println("result6 (result2 * result3): " + result6);

        System.out.println("\n");
        System.out.println("ANS #(3)");
        IRef<Integer> result7 = result6;
        System.out.println("Reference of result6: " + result7);

        System.out.println("\n");
        System.out.println("ANS #(4)");
        result1.setValue(3);
        System.out.println("result1: " + result1);
        System.out.println("result2: " + result2);
        System.out.println("result3 (result1 + result2): " + result3);
        System.out.println("result4 (result1 - result2): " + result4);
        System.out.println("result5 (result3 * result4): " + result5);
        System.out.println("result6 (result2 * result3): " + result6);

        System.out.println();
        result6.addFormula(new OperationSubtraction(), result3)
                .addFormula(new OperationSubtraction(), result1)
                .addFormula(new OperationMultiplication(), result2);
        System.out.println("Chain Operation of (result6 - result3 - result1) * result2: " + result6);

//        System.out.println();
//        cell1.setValue(2);
//        System.out.println("Change value of cell1 to: " + cell1);
//        System.out.println("cell1: " + cell1);
//        System.out.println("cell2: " + cell2);
//        System.out.println("cell3 (cell1 + cell2): " + cell3);
//        System.out.println("cell4 (cell1 - cell2): " + cell4);
//        System.out.println("cell5 (cell3 * cell4): " + cell5);
//        System.out.println("cell6 (cell2 * cell3): " + cell6);
//        cell6.addFormula(new OperationSubtraction(), cell3)
//                .addFormula(new OperationSubtraction(), cell1)
//                .addFormula(new OperationMultiplication(), cell2);
//        System.out.println("Chain Operation of (cell6 - cell3 - cell1) * cell2: " + cell6);

    }
}
