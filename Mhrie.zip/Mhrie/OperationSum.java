package senay;

import java.util.List;

public class OperationSum implements IOperation<Integer> {
    private int value;

    @Override
    public void compute(List<ICell<Integer>> cells) {
        this.value = 0;
        for (ICell<Integer> cell : cells) {
            this.value += cell.getValue();
        }
    }

    @Override
    public Integer getValue() {
        return value;
    }

}
