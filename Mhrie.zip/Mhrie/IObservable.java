package senay;

public interface IObservable {
    void addObserver(ICellObserver observer);
    void notifyObservers();
}
