package senay;

import java.util.List;

public class OperationSubtraction implements IOperation<Integer> {
    private int value;

    @Override
    public void compute(List<ICell<Integer>> cells) {
        if (cells.size() != 0){
            this.value = cells.get(0).getValue() * 2;
            for (ICell<Integer> cell : cells) {
                this.value -= cell.getValue();
            }
        }
        else {
            this.value = 0;
        }

    }

    @Override
    public Integer getValue() {
        return value;
    }

}
