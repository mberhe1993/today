package senay;

import java.util.ArrayList;
import java.util.List;

public class FormulaICell implements IFormulaICell<Integer> {
    private List<ICell<Integer>> cells;
    private int value;
    private IOperation<Integer> IOperation;
    private List<ICellObserver> observers;

    public FormulaICell(List<ICell<Integer>> cells, IOperation<Integer> IOperation) {
        this.cells = cells;
        this.observers = new ArrayList<>();
        for (ICell<Integer> cell : this.cells) {
            cell.addObserver(this);
        }
        this.IOperation = IOperation;
        this.IOperation.compute(this.cells);
        this.value = this.IOperation.getValue();
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    @Override
    public void addObserver(ICellObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (ICellObserver observer : this.observers) {
            observer.update();
        }
    }

    @Override
    public void update() {
        this.IOperation.compute(cells);
        this.value = IOperation.getValue();
        notifyObservers();
    }

    @Override
    public IFormulaICell<Integer> addFormula(IOperation<Integer> IOperation, ICell<Integer> cell) {
        IFormulaICell<Integer> currentCell = new FormulaICell(this.cells, this.IOperation);
        List<ICell<Integer>> newCells = new ArrayList<>();
        newCells.add(currentCell);
        newCells.add(cell);
        this.cells = newCells;
        this.IOperation = IOperation;

        this.IOperation.compute(this.cells);
        this.value = this.IOperation.getValue();
        this.observers = new ArrayList<>();
        for (ICell<Integer> c : this.cells) {
            c.addObserver(this);
        }

        return this;
    }

    @Override
    public void addCell(ICell<Integer> cell) {
        cell.addObserver(this);
        this.cells.add(cell);
        this.IOperation.compute(this.cells);
        this.value = this.IOperation.getValue();
    }

    @Override
    public String toString() {
        return getValue().toString();
    }



}
