package senay;

public interface ICell<E> extends IObservable {
    E getValue();
}
