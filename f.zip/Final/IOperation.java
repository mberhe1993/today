package Final;

public interface IOperation<E> {
	public void setBase(ICell<E> cell);
	public void operate(ICell<E> cell);
	public E getValue();
}
