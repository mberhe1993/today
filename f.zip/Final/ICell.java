package Final;

public interface ICell<E> extends ISubject {
	public E getValue();
}
