package Final;

public interface ICell_Formula<E> extends IObserver,Ref<E> {
	public ICell_Formula<E> addFormula(IOperation<E> operation, ICell<E> cell);
}
