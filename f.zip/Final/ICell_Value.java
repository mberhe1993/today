package Final;

public interface ICell_Value<E> extends Ref<E> {
	public void setValue(E value);
}
