package Final;

import java.util.ArrayList;
import java.util.List;

public class Cell_Formula implements ICell_Formula<Integer> {

	private ICell<Integer> cell1;
	private ICell<Integer> cell2;

	private IOperation<Integer> functor;
	private List<IObserver> observerList;

	public Cell_Formula(IOperation<Integer> functor, ICell<Integer> cell1, ICell<Integer> cell2) {
		this.functor = functor;

		observerList = new ArrayList<IObserver>();

		functor.setBase(cell1);
		functor.operate(cell2);
		
		cell1.addObserver(this);
		cell2.addObserver(this);

		this.cell1 = cell1;
		this.cell2 = cell2;
		this.functor = functor;

	}

	@Override
	public Integer getValue() {

		return functor.getValue();
	}

	@Override
	public void update() {

		functor.setBase(cell1);
		functor.operate(cell2);
		
		notifyObservers(); // when state (value) is changed, notify the observers
	}

	@Override
	public void addObserver(IObserver observer) {

		observerList.add(observer);
	}

	@Override
	public void notifyObservers() {

		for (IObserver observer : observerList) {
			observer.update();
		}
	}

	@Override
	public ICell_Formula<Integer> addFormula(IOperation<Integer> operation, ICell<Integer> cell) {
		
		this.cell1 =  new Cell_Formula(functor, this.cell1, this.cell2);
		this.cell2 = cell;

		operation.setBase(cell1);
		operation.operate(cell2);
		
		cell1.addObserver(this);
		cell2.addObserver(this);

		this.functor = operation;

		return this;
	}

	public String toString()
	{
		return this.getValue().toString();
	}
}
