package Final;

public class Operation_Multiply implements IOperation<Integer> {

	private ICell<Integer> cell1;
	private ICell<Integer> cell2;
	private Integer value;

	@Override
	public void operate(ICell<Integer> cell2) {
		this.cell2 = cell2;
		value = this.cell1.getValue() * this.cell2.getValue();
	}

	@Override
	public Integer getValue() {

		return value;
	}

	@Override
	public void setBase(ICell<Integer> cell1) {
		this.cell1 = cell1;
	}

}
