package Final;

public class Main {
	public static void main(String[] args) {

		// 1)
		System.out.println("1)");
		ICell_Value<Integer> a = new Cell_Value(5);
		ICell_Value<Integer> b = new Cell_Value(2);
		ICell_Formula<Integer> c = new Cell_Formula(new Operation_Add(), a, b);
		System.out.println("‌a : " + a);
		System.out.println("b : " + b);
		System.out.println("c (a+b) :" + c);

		// 2)
		System.out.println("\n2)");
		ICell_Formula<Integer> d = new Cell_Formula(new Operation_Substract(), a, b);
		System.out.println("d (a-b) : " + d);

		ICell_Formula<Integer> e = new Cell_Formula(new Operation_Multiply(), c, d);
		System.out.println("e (c*d) : " + e);

		ICell_Formula<Integer> f = new Cell_Formula(new Operation_Multiply(), b, c);
		System.out.println("f (b*c) : " + f);

		// 3)
		System.out.println("\n3)");
		Ref<Integer> g = f;
		System.out.println("ref of f :" + g);

		// 4)
		System.out.println("\n4)");
		a.setValue(3);
		System.out.println("‌a : " + a);
		System.out.println("b : " + b);
		System.out.println("c (a+b) : " + c);
		System.out.println("d (a-b) : " + d);
		System.out.println("e (c*d) : " + e);
		System.out.println("f (b*c) : " + f);		
		
		// testing to chain operations
		System.out.println();
		f.addFormula(new Operation_Substract(), c) 
		.addFormula(new Operation_Substract(), a)
		.addFormula(new Operation_Multiply(), b); //(f - c - a * b)
		System.out.println("Chain test ((f - c) - a) * b): "+ f);
		
		System.out.println("Changed a value to 2");
		a.setValue(2);
		System.out.println("‌a : " + a);
		System.out.println("b : " + b);
		System.out.println("c (a+b) : " + c);
		System.out.println("d (a-b) : " + d);
		System.out.println("e (c*d) : " + e);
		System.out.println("f (b*c) : " + f);	
		f.addFormula(new Operation_Substract(), c)
		.addFormula(new Operation_Substract(), a)
		.addFormula(new Operation_Multiply(), b); //(f - c - a * b)
		System.out.println("Chain test ((f - c - a) * b): "+ f);
		
	}
}
