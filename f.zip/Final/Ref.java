package Final;

public interface Ref<E> extends ICell<E>{
}
