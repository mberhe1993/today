package Final;

import java.util.ArrayList;
import java.util.List;

public class Cell_Value implements ICell_Value<Integer> {
	private Integer value = 0;
	private List<IObserver> observerList;
	
	public Cell_Value(Integer value)
	{
		this.value = value;
		observerList = new ArrayList<IObserver>();
	}
	
	@Override
	public void setValue(Integer value) {
		
		this.value = value;
		notifyObservers();
	}
	
	@Override
	public Integer getValue() {
		
		return value;
	}
	
	@Override
	public void addObserver(IObserver observer) {
		observerList.add(observer);
	}
	
	@Override
	public void notifyObservers() {
		
		for(IObserver observer:observerList)
		{
			observer.update();
		}
	}
	
	public String toString()
	{
		return this.getValue().toString();
	}
	
}
