package Final;

public interface ICommand {
	void execute();
}
