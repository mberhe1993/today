package Final;

public interface IObserver {
	public void update();
}
